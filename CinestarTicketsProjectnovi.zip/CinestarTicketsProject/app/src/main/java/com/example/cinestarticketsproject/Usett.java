package com.example.cinestarticketsproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Usett extends AppCompatActivity {
    public TextView text;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_usett);

        text =(TextView) findViewById(R.id.logout);
        text.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Usett.this, MainActivity.class);
                startActivity(i);
            }
        });
        text =(TextView) findViewById(R.id.settins);
        text.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Usett.this, Password.class);
                startActivity(i);
            }
        });
        text =(TextView) findViewById(R.id.edit);
        text.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Usett.this, Nmu.class);
                startActivity(i);
            }
        });
        text =(TextView) findViewById(R.id.editname);
        text.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Usett.this, names.class);
                startActivity(i);
            }
        });



    }

}